sinteractive --partition=shas --qos=normal --reservation=parallelD4 --time=6:00:00 --ntasks=24 --nodes=1
