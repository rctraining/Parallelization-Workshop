library(lineprof)
source("simple_profiling.R")
l <- lineprof(f())
l
