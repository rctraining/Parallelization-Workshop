install.packages("devtools")
library(devtools)
devtools::install_github("hadley/lineprof")
