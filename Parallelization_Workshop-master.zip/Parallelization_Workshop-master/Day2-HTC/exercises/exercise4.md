Convert the solution from exercise 2 ("background bash jobs in a Slurm
job") to use GNU parallel rather than background Bash jobs, and submit
it as a Slurm job. Reduce the requested `--ntasks` and observe the
execution time increase.


## Tips

* The payload for this job is effectively the solution from exercise
  3.
